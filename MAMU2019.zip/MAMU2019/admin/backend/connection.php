<?php
date_default_timezone_set('Asia/Manila');
$connect=mysqli_connect("localhost","root","","mamu2018") or die("CANNOT CONNECT TO ".mysqli_connect_error());	

?> 