
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Admin Part">
  <meta name="author" content="Pay-a-mann">
  <title>MAMU2019 | dashboard</title>
  <!-- Favicon -->
  <link href="./assets/img/theme/logo.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
  <link href="./assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
  <!-- Argon CSS -->
  <link type="text/css" href="./assets/css/argon.css" rel="stylesheet">
  <!-- Data tables-->
   <link type="text/css" href="./assets/css/argon.css/datatables/buttons.dataTables.min.css">
   <link type="text/css" href="./assets/css/argon.css/datatables/jquery.dataTables.min.css">
   <link type="text/css" href="./assets/css/argon.css/datatables/dataTables.jqueryui.css">

</head>
