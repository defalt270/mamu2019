<!-- Argon Scripts -->
  <!-- Core -->
  <script src="./assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="./assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Optional JS -->
  <script src="./assets/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="./assets/vendor/chart.js/dist/Chart.extension.js"></script>
  <!-- Argon JS -->
  <script src="./assets/js/argon.js?v=1.0.0"></script>

    <!--DATATABLES IMPORTANT :v-->
  <script type="text/javascript" language="javascript" src="./assets/datatables/jquery.dataTables.min.js"></script>
  <script type="text/javascript" language="javascript" src="./assets/datatables/dataTables.buttons.min.js"></script>
  <script type="text/javascript" language="javascript" src="./assets/datatables/buttons.flash.min.js"></script>
  <script type="text/javascript" language="javascript" src="./assets/datatables/jszip.min.js"></script>
  <script type="text/javascript" language="javascript" src="./assets/datatables/pdfmake.min.js"></script>
  <script type="text/javascript" language="javascript" src="./assets/datatables/vfs_fonts.js"></script>
  <script type="text/javascript" language="javascript" src="./assets/datatables/buttons.html5.min.js"></script>
  <script type="text/javascript" language="javascript" src="./assets/datatables/buttons.print.min.js"></script>
  <script type="text/javascript" language="javascript" src="./assets/datatables/dataTables.colReorder.min.js"></script>
  <script type="text/javascript" language="javascript" src="./assets/datatables/buttons.colVis.min.js"></script>